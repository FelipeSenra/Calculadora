#include<iostream>

/*int main(){
Kernel nucleo = new Kernel();

}
*/
