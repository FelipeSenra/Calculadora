#include <string>
#include <iostream>
#include <vector>
#include "Interface/Interface.h"

interface(){

}
  std::string getString(){
  return
  }
  void plot(std::string result){

  }
